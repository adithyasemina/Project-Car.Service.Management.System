﻿namespace Expenses_Details
{
    internal class iData
    {
    }
}